library(dplyr)
library(ggplot2)


#Loading the data set
loan <- read.csv ("loan.csv" , header=T,stringsAsFactors = F )

#Data Cleaning----

# Check for  #N/A Values in the main columns of the dataframe

sum(is.na(loan$id))
sum(is.na(loan$member_id))
sum(is.na(loan$loan_amnt))
sum(is.na(loan$funded_amnt))

#Check for unique Loan id's

unique_id <- length(unique(loan$id)) 
unique_member_id <- length(unique(loan$member_id)) 

#Removing the columns with NA values.


loan <- loan[,-(50:51),drop=FALSE]

loan <- loan[,-(54:111),drop=FALSE]

loan <- loan[,-(52:53),drop=FALSE]


#changing the emp_title to lower case
loan$emp_title <- factor(tolower(loan$emp_title)) 

loan$title <- factor(tolower(loan$title))

#Converting dates into standard format

loan$issue_d <- paste("01-",loan$issue_d,sep = "")
loan$issue_d <- as.Date(loan$issue_d,format = "%d-%b-%y")

loan$earliest_cr_line <- paste("01-",loan$earliest_cr_line,sep = "")
loan$earliest_cr_line <- as.Date(loan$earliest_cr_line,format = "%d-%b-%y")

loan$last_pymnt_d <- paste("01-",loan$last_pymnt_d, sep = "")
loan$last_pymnt_d <- as.Date(loan$last_pymnt_d,format = "%d-%b-%y")

loan$last_credit_pull_d <- paste("01-",loan$last_credit_pull_d, sep = "")
loan$last_credit_pull_d <- as.Date(loan$last_credit_pull_d,format = "%d-%b-%y")

# Removing % from Interest Rate column

loan$int_rate <- gsub('%','',loan$int_rate) 

#Removing months from term column

loan$term <- gsub('months','',loan$term) 

#Creating an additional column to identify charged off customers

loan$chargedoff <- ifelse(loan$loan_status == "Fully Paid" | loan$loan_status == "Current","No","Yes")

#Total loans issued in each particular year

loan$Issued_Year <- format(loan$issue_d,"%Y")

loan$Quarter <- quarters(loan$issue_d) # To extract the quarter when the loan was issued

#Plot showing the count of loans issued in each particular year.
ggplot(loan,aes(x=Issued_Year,fill=Quarter)) + geom_bar(position="dodge") 

loan$int_rate <- as.numeric(loan$int_rate) #Converting interest rate to numeric                                                                                                                                                               

#To make an interest slab on the basis of Interest rate
loan <- mutate(loan, Interest_slab = ifelse(loan$int_rate >=5 & loan$int_rate < 9,'5-9 percent',
                                            ifelse(loan$int_rate>=9 & loan$int_rate < 13,'9-13 percent',
                                                   ifelse(loan$int_rate >= 13 & loan$int_rate <17,'13-17 percent',
                                                          ifelse(loan$int_rate >= 17 & loan$int_rate <21,'17-21 percent',
                                                                 ifelse(loan$int_rate >= 21 & loan$int_rate <25,'21-25 percent','Other'))))))

#Creating an Income slab

loan <- mutate(loan, Income_slab = ifelse(loan$annual_inc >=0 & loan$annual_inc < 20000,'0-20k',
                                          ifelse(loan$annual_inc>=20000 & loan$annual_inc < 40000,'20k-40k',
                                                 ifelse(loan$annual_inc >= 40000 & loan$annual_inc <60000,'40k-60k',
                                                        ifelse(loan$annual_inc >= 60000 & loan$annual_inc <80000,'60k-80k',
                                                               ifelse(loan$annual_inc >= 80000 & loan$annual_inc <100000,'80k-100k','100k+'))))))


#Creating a revolving slab
loan <- mutate(loan, revbal_slab = ifelse(loan$revol_bal >=0 & loan$revol_bal < 25000,'0-25k',
                                          ifelse(loan$revol_bal>=25000 & loan$revol_bal < 50000,'25k-50k',
                                                 ifelse(loan$revol_bal >= 50000 & loan$revol_bal <75000,'50k-75k',
                                                        ifelse(loan$revol_bal >= 75000 & loan$revol_bal <100000,'75k-100k',
                                                               ifelse(loan$revol_bal >= 100000 & loan$revol_bal <125000,'100k-125k','125k+'))))))


# Univariate Analysis----
#1. Term vs Loan Status analysis
ggplot(loan, aes(x=term,fill = chargedoff)) +geom_bar()+labs(title = "Loan Term Vs Charged off Loan", x = "Term (months)", y="Count of Customer")+stat_count(aes(y=..count..,label=..count..),geom="text",vjust=-1)

#2. Grade vs Loan Status 
ggplot(loan, aes(x=grade,fill = chargedoff)) +geom_bar()+labs(title = "Grades Vs Charged off Loan", x = "Grade", y="Count of Customer")+stat_count(aes(y=..count..,label=..count..),geom="text",vjust=-1)

#3.Purpose vs Loan Status
ggplot(loan, aes(x=purpose,fill = chargedoff)) +geom_bar()+labs(title = "Charged Off loan based on Purpose", x = "Purpose", y="Count of Customer")+stat_count(aes(y=..count..,label=..count..),geom="text",vjust=-1)

#4.Verification status vs Loan Status
ggplot(loan, aes(x=verification_status,fill = chargedoff)) +geom_bar()+labs(title = "Charged Off loan based on Verfication Status", x = "Verification Status", y="Count of Customer")+stat_count(aes(y=..count..,label=..count..),geom="text",vjust=-1)

#5.Income slab vs Loan Status
ggplot(loan, aes(x=Income_slab,fill = chargedoff)) +geom_bar()+labs(title = "Distribution of Loans based on annual income", x = "Annual Income", y="Count of Customer")+stat_count(aes(y=..count..,label=..count..),geom="text",vjust=-1)

#6.Interest rate vs Loan Status
ggplot(loan, aes(x=Interest_slab,fill = chargedoff)) +geom_bar()+labs(title = "Charged Off loan based on Interest Rate", x = "Interest Rate slab", y="Count of Customer")+stat_count(aes(y=..count..,label=..count..),geom="text",vjust=-1)

#7. State vs Loan Status
ggplot(loan, aes(x=addr_state,fill = chargedoff)) +geom_bar()+labs(title = "Charged Off loan based on states", x = "states", y="Count of Customer")+stat_count(aes(y=..count..,label=..count..),geom="text",vjust=-1)

#8. Revolving balance vs Loan Status

ggplot(loan, aes(x=revbal_slab,fill = chargedoff)) +geom_bar()+labs(title = "Charged Off loan based on revolving Balance", x = "Revolving Balance", y="Count of Customer")+stat_count(aes(y=..count..,label=..count..),geom="text",vjust=-1)


#Bivariate Analysis----

#1. Comparison of Income slab with grade for Charged off customers
ggplot(loan, aes(x=Income_slab,fill = chargedoff)) +geom_bar()+facet_wrap(~grade)+labs(title = "Grades Vs Charged off Loan", x = "Income slab", y="Count of Customer")+stat_count(aes(y=..count..,label=..count..),geom="text",vjust=-1)

#2. Comparison of Home ownership with term for Charged off customers
ggplot(loan, aes(x=home_ownership,fill = chargedoff)) +geom_bar()+facet_wrap(~term)+labs(title = "Homeownership Vs Charged off Loan based on term", x = "Home ownership", y="Count of Customer")+stat_count(aes(y=..count..,label=..count..),geom="text",vjust=-1)

#3. Comparison of Delinq_2yrs with Charged off customers
ggplot(loan, aes(x=delinq_2yrs,fill = chargedoff)) +geom_bar()+facet_wrap(~Income_slab)+labs(title = "Purpose Vs Charged off customers based on Delinq-2years", x = "delinq_2years", y="Count of Customer")+stat_count(aes(y=..count..,label=..count..),geom="text",vjust=-1)

#Derived Metrices
#Loan Current Account Ratio Calculation
loan <- mutate(loan,Current_Account_Ratio=open_acc/total_acc)

loan$emp_length <-factor(loan$emp_length)

subset1 <- data.frame(loan$id,loan$emp_length,loan$Current_Account_Ratio)

emp_length_groups <- group_by(subset1,loan.emp_length)

Average_Current_Account_Ratio <- summarise(emp_length_groups,Current_Ratio = mean(loan.Current_Account_Ratio,na.rm = T))

colnames(Average_Current_Account_Ratio) <- c("Emp_length","Average_Current_Acc_Ratio") #changing the column names of the above created dataframe.

Current_Account_ratio_plot = plot(Average_Current_Account_Ratio$Emp_length, Average_Current_Account_Ratio$Average_Current_Acc_Ratio)

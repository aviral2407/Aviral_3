
#########Loading libraries----
library(ggplot2)
library(cowplot)
library(dplyr)
library(tidyr)
library(stringr)
library(GGally)
library(caret)
library(MASS)
library(car)
library(e1071)
library(caTools)
library(ROCR)

#Data Loading and Preperation----
########Loading the Dataset
General_Data <- read.csv("general_data.csv")
Employee_Survey_Data <- read.csv("employee_survey_data.csv")
Manager_Survey_Data <- read.csv("manager_survey_data.csv")
In_Time <- read.csv("in_time.csv",stringsAsFactors = FALSE)
Out_Time <- read.csv("out_time.csv",stringsAsFactors = FALSE)

str(General_Data)   #4410 observations of 24 variables
str(Employee_Survey_Data) #4410 observations of 4 variables
str(Manager_Survey_Data) #4410 observations of 3 variables
str(In_Time) #4410 observations of 262 variables
str(Out_Time) #4410 observations of 262 variables

#Checking for all the null values in the data Frames
sum(is.null(General_Data))
sum(is.null(Employee_Survey_Data))
sum(is.null(Manager_Survey_Data))
sum(is.null(In_Time))
sum(is.null(Out_Time))

#Checking all the NA values in the data frames
sum(is.na(General_Data))
sum(is.na(Employee_Survey_Data))
sum(is.na(Manager_Survey_Data))
sum(is.na(In_Time))
sum(is.na(Out_Time))

#providing column names to the 1st column For InTime and OutTime Dataframe 
colnames(In_Time)[1] <- "EmployeeID"
colnames(Out_Time)[1] <- "EmployeeID"

#Checking the count of unique records in all dataframes.
length(unique(Employee_Survey_Data$EmployeeID))
length(unique(Manager_Survey_Data$EmployeeID))
length(unique(General_Data$EmployeeID))
length(unique(In_Time$EmployeeID))
length(unique(Out_Time$EmployeeID))

#Identical EmployeeID across the 3 datasets
setdiff(General_Data$EmployeeID,Employee_Survey_Data$EmployeeID)
setdiff(General_Data$EmployeeID,Manager_Survey_Data$EmployeeID)
setdiff(General_Data$EmployeeID,In_Time$EmployeeID)
setdiff(General_Data$EmployeeID,Out_Time$EmployeeID)

#Merging General data with Employee Survey Data
General_Data <- merge(x=General_Data,y=Employee_Survey_Data,by = "EmployeeID",all = F)
#Merging General data with Manager Survey Data
General_Data <- merge(x=General_Data,y=Manager_Survey_Data,by = "EmployeeID",all = F)

#time conversion into proper format
In_Time[ , 2:262] <- lapply(In_Time[ , 2:262],function(x)  as.POSIXlt(x,format ="%Y-%m-%d %H:%M:%S" ))
Out_Time[ , 2:262] <- lapply(Out_Time[ , 2:262],function(x)  as.POSIXlt(x,format ="%Y-%m-%d %H:%M:%S" ))
View(In_Time)
str(In_Time)
#creating Time_Diff Data Frame 
Time_Diff <- Out_Time-In_Time
View(Time_Diff)
#Adding EmployeeID value to Time_Diff Data Frame
Time_Diff$EmployeeID <- In_Time$EmployeeID 
sum(is.na(Time_Diff))

###  number of NA's are same for all three dataframes so in-time & out-time for all days are mentioned
#Rounding the Time to 2 digits
Time_Diff[,2:262] <- lapply(Time_Diff[,2:262],function(x) round(x,digits = 2))

#Removing the columns with all NA variables considering that all employee in and out time is NA.
Time_Diff <- Time_Diff[,colSums(is.na(Time_Diff))<nrow(Time_Diff)]
sum(is.na(Time_Diff))
Time_Diff_1 <- gather(Time_Diff,date,working_hours,-EmployeeID )

#Converting "date" column, in date format.
#so first removing "X"
Time_Diff_1$date <- gsub('X','',Time_Diff_1$date) 

#Converting to Date Format
Time_Diff_1$date <- as.Date(Time_Diff_1$date,format = "%Y.%m.%d") 

#To extract the quarter from the date
Time_Diff_1$Quarter <- (quarters(Time_Diff_1$date))

#To find average working hours per quarter per employee
Time_Diff_1 <- group_by(Time_Diff_1,EmployeeID,Quarter)
Average_Working_Hours_Quarter <- summarise(Time_Diff_1,Average_Quaterly=mean(working_hours,na.rm = T))
Average_Working_Hours_Quarter$Average_Quaterly <- round(Average_Working_Hours_Quarter$Average_Quaterly,digits = 2) # Rounding off to nearest 2 digits

#Converting data to wide format
Avg_Quarter <-spread(Average_Working_Hours_Quarter,Quarter,Average_Quaterly)

#Merging Avg_Quarter in General Dataset
General_Data <- merge(x=General_Data,y=Avg_Quarter,by = "EmployeeID",all = F)

#Assuming NA values as "leaves" taken by each employee in the entire year, 
#Finding NA values for each staff
staff_leave <- rowSums(is.na(Time_Diff))

#the sum total of leaves is calculated for each employee and added in General Data frame.
General_Data$staff_leave <- staff_leave
sum(General_Data$staff_leave)

#Finding the sum of NA values in General Dataframe
na_sum <- sum(is.na(General_Data))
na_sum
total_elements <- nrow(General_Data)*ncol(General_Data)
perc <- (na_sum/total_elements)*100
perc

# Dataframe showing the rows which have any NA values in the General Dataframe
missing <- General_Data[rowSums(is.na(General_Data)) > 0,]

#since NA percentage is 0.07 we are removing the same.
General_Data <- na.omit(General_Data)
sum(is.na(General_Data))

#Changing column names in General Data frame
colnames(General_Data)[30] <- "Average_Working_Hours_Q1"
colnames(General_Data)[31] <- "Average_Working_Hours_Q2"
colnames(General_Data)[32] <- "Average_Working_Hours_Q3"
colnames(General_Data)[33] <- "Average_Working_Hours_Q4"

# Changing the datatype of the created derived variables
General_Data[,30:33] <- lapply(General_Data[,30:33], function(x) as.numeric(x))


#Plotting Categorical Variables----
bar_theme1<- theme(axis.text.x = element_text(angle = 45, hjust = 0.5, vjust = 0.5), 
                   legend.position="none")

#Creating the plots of all the categorical variables
#Plot for Education,Department,EducationField and BusinessTravel
plot_grid(ggplot(General_Data, aes(x=Education,fill=Attrition))+ geom_bar(),
          ggplot(General_Data, aes(x=Department,fill=Attrition))+ geom_bar()+bar_theme1,
          ggplot(General_Data, aes(x=EducationField,fill=Attrition))+ geom_bar()+bar_theme1,
          ggplot(General_Data, aes(x=BusinessTravel,fill=Attrition))+ geom_bar()+bar_theme1,
          align = "h")   

#Plot for MaritalStatus,StockOptionLevel,Gender and Over18
plot_grid(ggplot(General_Data, aes(x=MaritalStatus,fill=Attrition))+ geom_bar(), 
          ggplot(General_Data, aes(x=StockOptionLevel,fill=Attrition))+ geom_bar()+bar_theme1,
          ggplot(General_Data, aes(x=Gender,fill=Attrition))+ geom_bar()+bar_theme1,
          ggplot(General_Data, aes(x=Over18,fill=Attrition))+ geom_bar()+bar_theme1,
          align = "h") 

#Plot for WorkLifeBalance and EnvironmentSatisfaction
plot_grid(ggplot(General_Data, aes(x=WorkLifeBalance,fill=Attrition))+ geom_bar(), 
          ggplot(General_Data, aes(x=EnvironmentSatisfaction,fill=Attrition))+ geom_bar()+bar_theme1,
          align = "h")   
#Plot for JobLevel,JobInvolvement,JobRole and JobSatisfaction
plot_grid(ggplot(General_Data, aes(x=JobLevel,fill=Attrition))+ geom_bar(), 
          ggplot(General_Data, aes(x=JobInvolvement,fill=Attrition))+ geom_bar()+bar_theme1,
          ggplot(General_Data, aes(x=JobRole,fill=Attrition))+ geom_bar()+bar_theme1,
          ggplot(General_Data, aes(x=JobSatisfaction,fill=Attrition))+ geom_bar()+bar_theme1,
          align = "h")

#Plotting Continuos Variables----
#Outlier treatment for continous variables
box_theme<- theme(axis.line=element_blank(),axis.title=element_blank(), 
                  axis.ticks=element_blank(), axis.text=element_blank())

box_theme_y<- theme(axis.line.y=element_blank(),axis.title.y=element_blank(), 
                    axis.ticks.y=element_blank(), axis.text.y=element_blank(),
                    legend.position="none")

##Checking outliers in Age
plot_grid(ggplot(General_Data, aes(Age))+ geom_histogram(binwidth = 10),
          ggplot(General_Data, aes(x="",y=Age))+ geom_boxplot(width=0.1)+coord_flip()+box_theme, 
          align = "v",ncol = 1)
#No Outlier

##Checking outliers in Distance from home
plot_grid(ggplot(General_Data, aes(DistanceFromHome))+ geom_histogram(binwidth = 10),
          ggplot(General_Data, aes(x="",y=DistanceFromHome))+ geom_boxplot(width=0.1)+coord_flip()+box_theme, 
          align = "v",ncol = 1) 
#No Outlier

##Checking outliers in Monthly Income
plot_grid(ggplot(General_Data, aes(MonthlyIncome))+ geom_histogram(binwidth = 10),
          ggplot(General_Data, aes(x="",y=MonthlyIncome))+ geom_boxplot(width=0.1)+coord_flip()+box_theme, 
          align = "v",ncol = 1) 
#outliers present

#Treating outliers for salary
quantile(General_Data$MonthlyIncome,seq(0,1,0.01))
boxplot(General_Data$MonthlyIncome)
General_Data$MonthlyIncome[which(General_Data$MonthlyIncome>152020)]<- 152020

##Checking outliers in NumCompaniesworked
General_Data$NumCompaniesWorked <- as.numeric(General_Data$NumCompaniesWorked)
plot_grid(ggplot(General_Data, aes(NumCompaniesWorked))+ geom_histogram(binwidth = 10),
          ggplot(General_Data, aes(x="",y=NumCompaniesWorked))+ geom_boxplot(width=0.1)+coord_flip()+box_theme, 
          align = "v",ncol = 1) 
#No outliers present

##Checking outliers in PercentSalaryHike
plot_grid(ggplot(General_Data, aes(PercentSalaryHike))+ geom_histogram(binwidth = 10),
          ggplot(General_Data, aes(x="",y=PercentSalaryHike))+ geom_boxplot(width=0.1)+coord_flip()+box_theme, 
          align = "v",ncol = 1) 
#No outliers present

##Checking outliers in TotalWorkingYears 
plot_grid(ggplot(General_Data, aes(TotalWorkingYears))+ geom_histogram(binwidth = 10),
          ggplot(General_Data, aes(x="",y=TotalWorkingYears))+ geom_boxplot(width=0.1)+coord_flip()+box_theme, 
          align = "v",ncol = 1) 
#Outliers present

#Treating Outlier for total working years
quantile(General_Data$TotalWorkingYears,seq(0,1,0.01))
boxplot(General_Data$TotalWorkingYears)
General_Data$TotalWorkingYears[which(General_Data$TotalWorkingYears>28)]<- 28
summary(General_Data$TotalWorkingYears)

#Checking Outliers for YearsAtCompany
plot_grid(ggplot(General_Data, aes(YearsAtCompany))+ geom_histogram(binwidth = 10),  
          ggplot(General_Data, aes(x="",y=YearsAtCompany))+ geom_boxplot(width=0.1)+coord_flip()+box_theme, 
          align = "v",ncol = 1) #Outliers present

#Treating Outliers in YearAtCompany
quantile(General_Data$YearsAtCompany,seq(0,1,0.01))
boxplot(General_Data$YearsAtCompany)
General_Data$YearsAtCompany[which(General_Data$YearsAtCompany>19)]<- 19
summary(General_Data$YearsAtCompany)

#Checking Outliers for Years since last promotion variable 
plot_grid(ggplot(General_Data, aes(YearsSinceLastPromotion))+ geom_histogram(binwidth = 10),
          ggplot(General_Data, aes(x="",y=YearsSinceLastPromotion))+ geom_boxplot(width=0.1)+coord_flip()+box_theme, 
          align = "v",ncol = 1) #Outliers present

#Treating Outliers in YearsSinceLastPromotion
quantile(General_Data$YearsSinceLastPromotion,seq(0,1,0.01))
boxplot(General_Data$YearsSinceLastPromotion)
General_Data$YearsSinceLastPromotion[which(General_Data$YearsSinceLastPromotion>6)]<- 6
summary(General_Data$YearsSinceLastPromotion)

#Checking Outliers for YearswithCurrentManager
plot_grid(ggplot(General_Data, aes(YearsWithCurrManager))+ geom_histogram(binwidth = 10),
          ggplot(General_Data, aes(x="",y=YearsWithCurrManager))+ geom_boxplot(width=0.1)+coord_flip()+box_theme, 
          align = "v",ncol = 1) #Outliers present

#Treating Outliers in YearswithCurrentManager
quantile(General_Data$YearsWithCurrManager,seq(0,1,0.01))
boxplot(General_Data$YearsWithCurrManager)
General_Data$YearsWithCurrManager[which(General_Data$YearsWithCurrManager>14)]<- 14
summary(General_Data$YearsWithCurrManager)

# Boxplots of numeric variables
plot_grid(ggplot(General_Data, aes(x=Attrition,y=PercentSalaryHike, fill=Attrition))+ geom_boxplot(width=0.2)+ 
            coord_flip() +theme(legend.position="none"),
          ggplot(General_Data, aes(x=Attrition,y=MonthlyIncome, fill=Attrition))+ geom_boxplot(width=0.2)+
            coord_flip() + box_theme_y,
          ggplot(General_Data, aes(x=Attrition,y=TotalWorkingYears, fill=Attrition))+ geom_boxplot(width=0.2)+
            coord_flip() + box_theme_y,
          ggplot(General_Data, aes(x=Attrition,y=YearsAtCompany, fill=Attrition))+ geom_boxplot(width=0.2)+
            coord_flip() + box_theme_y,
          align = "v",nrow = 1)

plot_grid(ggplot(General_Data, aes(x=Attrition,y=YearsSinceLastPromotion, fill=Attrition))+ geom_boxplot(width=0.2)+ 
            coord_flip() +theme(legend.position="none"),
          ggplot(General_Data, aes(x=Attrition,y=YearsWithCurrManager, fill=Attrition))+ geom_boxplot(width=0.2)+
            coord_flip() + box_theme_y,
          ggplot(General_Data, aes(x=Attrition,y=DistanceFromHome, fill=Attrition))+ geom_boxplot(width=0.2)+
            coord_flip() + box_theme_y,
          ggplot(General_Data, aes(x=Attrition,y=TrainingTimesLastYear, fill=Attrition))+ geom_boxplot(width=0.2)+
            coord_flip() + box_theme_y,
          align = "v",nrow = 1)

plot_grid(ggplot(General_Data, aes(x=Attrition,y=Average_Working_Hours_Q1, fill=Attrition))+ geom_boxplot(width=0.2)+ 
            coord_flip() +theme(legend.position="none"),
          ggplot(General_Data, aes(x=Attrition,y=Average_Working_Hours_Q2, fill=Attrition))+ geom_boxplot(width=0.2)+
            coord_flip() + box_theme_y,
          ggplot(General_Data, aes(x=Attrition,y=Average_Working_Hours_Q3, fill=Attrition))+ geom_boxplot(width=0.2)+
            coord_flip() + box_theme_y,
          ggplot(General_Data, aes(x=Attrition,y=Average_Working_Hours_Q4, fill=Attrition))+ geom_boxplot(width=0.2)+
            coord_flip() + box_theme_y,
          ggplot(General_Data, aes(x=Attrition,y=staff_leave, fill=Attrition))+ geom_boxplot(width=0.2)+
            coord_flip() + box_theme_y,
          align = "v",nrow = 1)

#Final Data Frame---- 
# Creating new data Frame for further analysis
Final_Data <- General_Data

#Removing Redundant Variables such as Over18 and EmployeeCount
Final_Data$Over18 <- NULL
Final_Data$EmployeeCount <- NULL
Final_Data$StandardHours <- NULL
summary(Final_Data)

#Checking correlation between continuous variables
ggpairs(Final_Data[,c("PercentSalaryHike", "MonthlyIncome", "TotalWorkingYears", "YearsAtCompany", "YearsSinceLastPromotion", "YearsWithCurrManager",
                      "DistanceFromHome","NumCompaniesWorked","TrainingTimesLastYear","Average_Working_Hours_Q1",
                      "Average_Working_Hours_Q2","Average_Working_Hours_Q3","Average_Working_Hours_Q4","staff_leave")])

#Working hours are highly correlated amongst themselves, corr  approx 0.99


#Scaling the continuous variables
Final_Data$PercentSalaryHike<- scale(Final_Data$PercentSalaryHike)
Final_Data$MonthlyIncome<- scale(Final_Data$MonthlyIncome)
Final_Data$TotalWorkingYears<- scale(Final_Data$TotalWorkingYears)
Final_Data$YearsAtCompany<- scale(Final_Data$YearsAtCompany)
Final_Data$YearsSinceLastPromotion<- scale(Final_Data$YearsSinceLastPromotion)
Final_Data$YearsWithCurrManager<- scale(Final_Data$YearsWithCurrManager)
Final_Data$DistanceFromHome<- scale(Final_Data$DistanceFromHome)
Final_Data$NumCompaniesWorked<- scale(Final_Data$NumCompaniesWorked)
Final_Data$TrainingTimesLastYear<- scale(Final_Data$TrainingTimesLastYear)
Final_Data$Average_Working_Hours_Q1 <- scale(Final_Data$Average_Working_Hours_Q1)
Final_Data$Average_Working_Hours_Q2 <- scale(Final_Data$Average_Working_Hours_Q2)
Final_Data$Average_Working_Hours_Q3 <- scale(Final_Data$Average_Working_Hours_Q3)
Final_Data$Average_Working_Hours_Q4 <- scale(Final_Data$Average_Working_Hours_Q4)
Final_Data$staff_leave <- scale(Final_Data$staff_leave)


# converting Attrition variable from Final Dataset from No/Yes character to factorwith levels 0/1 
Final_Data$Attrition<- ifelse(Final_Data$Attrition=="Yes",1,0)

# Checking Attrition rate of employees
Attrition <- sum(Final_Data$Attrition)/nrow(Final_Data)
Attrition # 16.16% attrition rate. 

# creating a dataframe of categorical features
HR_Categorical<- Final_Data[,c(4,5,7:12,16,22:26)]

# converting categorical attributes to factor
HR_Categorical<- data.frame(sapply(HR_Categorical, function(x) factor(x)))
str(HR_Categorical)

# creating dummy variables for factor attributes
dummies_HR<- data.frame(sapply(HR_Categorical, 
                               function(x) data.frame(model.matrix(~x-1,data =HR_Categorical))[,-1]))

#Merging the dummy variables to existing data frame
HR_final<- cbind(Final_Data[,c(1:3,6,13:15,17:21,27:31)],dummies_HR) 
View(HR_final) #4300 obs. of  61 variables

#Model Building----
# splitting the data between train and test
set.seed(100)

HR_indices = sample.split(HR_final, SplitRatio = 0.7)

train = HR_final[HR_indices,]

test = HR_final[!(HR_indices),]

# Logistic Regression: 

#Initial model
model_1 = glm(Attrition ~ ., data = train, family = "binomial")
summary(model_1) #AIC 2113.2 coeff..nullDev 2643.9 resDev 1991.2

# Building second model using StepAIC function
model_2<- stepAIC(model_1, direction="both")
summary(model_2)

# Removing multicollinearity through VIF check
sort(vif(model_2))

#Excluding Average_Working_hours_Q1
model_3<- glm(formula = Attrition ~ Age + DistanceFromHome + NumCompaniesWorked + 
                TotalWorkingYears + TrainingTimesLastYear + YearsAtCompany + 
                YearsSinceLastPromotion + YearsWithCurrManager +  
                Average_Working_Hours_Q3 + BusinessTravel.xTravel_Frequently + 
                BusinessTravel.xTravel_Rarely + Department.xResearch...Development + 
                Department.xSales + Education.x5 + EducationField.xTechnical.Degree + 
                JobLevel.x2 + JobLevel.x5 + JobRole.xManager + JobRole.xManufacturing.Director + 
                JobRole.xResearch.Director + MaritalStatus.xMarried + MaritalStatus.xSingle + 
                StockOptionLevel.x1 + EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                WorkLifeBalance.x4 + JobInvolvement.x3 + Education.x2, family = "binomial", 
              data = train)
summary(model_3) 
sort(vif(model_3))

# Removing YearsAt Company variable with VIF 4.40 and p-value 0.08
model_4<- glm(formula = Attrition ~ Age + DistanceFromHome + NumCompaniesWorked + 
                TotalWorkingYears + TrainingTimesLastYear + 
                YearsSinceLastPromotion + YearsWithCurrManager +  
                Average_Working_Hours_Q3 + BusinessTravel.xTravel_Frequently + 
                BusinessTravel.xTravel_Rarely + Department.xResearch...Development + 
                Department.xSales + Education.x5 + EducationField.xTechnical.Degree + 
                JobLevel.x2 + JobLevel.x5 + JobRole.xManager + JobRole.xManufacturing.Director + 
                JobRole.xResearch.Director + MaritalStatus.xMarried + MaritalStatus.xSingle + 
                StockOptionLevel.x1 + EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                WorkLifeBalance.x4 + JobInvolvement.x3 + Education.x2, family = "binomial", 
              data = train)

summary(model_4) 
sort(vif(model_4))

####Removing DistancefromHome  variable with VIF 1.028520 and p-value 0.151854. Since p-value is highest for the variable,
# we are removing it
model_5<- glm(formula = Attrition ~ Age + NumCompaniesWorked + 
                TotalWorkingYears + TrainingTimesLastYear + 
                YearsSinceLastPromotion + YearsWithCurrManager +  
                Average_Working_Hours_Q3 + BusinessTravel.xTravel_Frequently + 
                BusinessTravel.xTravel_Rarely + Department.xResearch...Development + 
                Department.xSales +Education.x5 + EducationField.xTechnical.Degree + 
                JobLevel.x2 + JobLevel.x5 + JobRole.xManager + JobRole.xManufacturing.Director + 
                JobRole.xResearch.Director + MaritalStatus.xMarried + MaritalStatus.xSingle + 
                StockOptionLevel.x1 + EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                WorkLifeBalance.x4 + JobInvolvement.x3 + Education.x2, family = "binomial", 
              data = train)

summary(model_5) 
sort(vif(model_5))

####Removing Education.x5  variable with VIF 1.041431 and p-value 0.146898. Since p-value is highest for the variable,
# we are removing it
model_6<- glm(formula = Attrition ~ Age + NumCompaniesWorked + 
                TotalWorkingYears + TrainingTimesLastYear + 
                YearsSinceLastPromotion + YearsWithCurrManager +  
                Average_Working_Hours_Q3 + BusinessTravel.xTravel_Frequently + 
                BusinessTravel.xTravel_Rarely + Department.xResearch...Development + 
                Department.xSales + EducationField.xTechnical.Degree + 
                JobLevel.x2 + JobLevel.x5 + JobRole.xManager + JobRole.xManufacturing.Director + 
                JobRole.xResearch.Director + MaritalStatus.xMarried + MaritalStatus.xSingle + 
                StockOptionLevel.x1 + EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                WorkLifeBalance.x4 + JobInvolvement.x3 + Education.x2, family = "binomial", 
              data = train)

summary(model_6) 
sort(vif(model_6))

####Removing EducationField.Technical.Degree variable with VIF 1.02 and p-value 0.1064. Since p-value is highest for the variable,
# we are removing it
model_7<- glm(formula = Attrition ~ Age + NumCompaniesWorked + 
                TotalWorkingYears + TrainingTimesLastYear + 
                YearsSinceLastPromotion + YearsWithCurrManager +  
                Average_Working_Hours_Q3 + BusinessTravel.xTravel_Frequently + 
                BusinessTravel.xTravel_Rarely + Department.xResearch...Development + 
                Department.xSales + 
                JobLevel.x2 + JobLevel.x5 + JobRole.xManager + JobRole.xManufacturing.Director + 
                JobRole.xResearch.Director + MaritalStatus.xMarried + MaritalStatus.xSingle + 
                StockOptionLevel.x1 + EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                WorkLifeBalance.x4 + JobInvolvement.x3 + Education.x2, family = "binomial", 
              data = train)

summary(model_7) 
sort(vif(model_7))

####Removing JobRole.x2 variable with VIF 1.06 and p-value 0.118222. Since p-value is highest for the variable,
# we are removing it
model_8<- glm(formula = Attrition ~ Age + NumCompaniesWorked + 
                TotalWorkingYears + TrainingTimesLastYear + 
                YearsSinceLastPromotion + YearsWithCurrManager +  
                Average_Working_Hours_Q3 + BusinessTravel.xTravel_Frequently + 
                BusinessTravel.xTravel_Rarely + Department.xResearch...Development + 
                Department.xSales + JobLevel.x5 + JobRole.xManager + JobRole.xManufacturing.Director + 
                JobRole.xResearch.Director + MaritalStatus.xMarried + MaritalStatus.xSingle + 
                StockOptionLevel.x1 + EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                WorkLifeBalance.x4 + JobInvolvement.x3 + Education.x2, family = "binomial", 
              data = train)


summary(model_8) 
sort(vif(model_8))

####Removing Education.x2 variable with VIF 1.05 and p-value 0.670. Since p-value is highest for the variable,
# we are removing it
model_9<- glm(formula = Attrition ~ Age + NumCompaniesWorked + 
                TotalWorkingYears + TrainingTimesLastYear + 
                YearsSinceLastPromotion + YearsWithCurrManager +  
                Average_Working_Hours_Q3 + BusinessTravel.xTravel_Frequently + 
                BusinessTravel.xTravel_Rarely + Department.xResearch...Development + 
                Department.xSales + JobLevel.x5 + JobRole.xManager + JobRole.xManufacturing.Director + 
                JobRole.xResearch.Director + MaritalStatus.xMarried + MaritalStatus.xSingle + 
                StockOptionLevel.x1 + EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                WorkLifeBalance.x4 + JobInvolvement.x3 , family = "binomial", 
              data = train)


summary(model_9) 
sort(vif(model_9))

####Removing MaritalStatus.xMarried variable with VIF 2.245and p-value 0.619. Since p-value is highest for the variable,
# we are removing it
model_10<- glm(formula = Attrition ~ Age + NumCompaniesWorked + 
                 TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager +  
                 Average_Working_Hours_Q3 + BusinessTravel.xTravel_Frequently + 
                 BusinessTravel.xTravel_Rarely + Department.xResearch...Development + 
                 Department.xSales + JobLevel.x5 + JobRole.xManager + JobRole.xManufacturing.Director + 
                 JobRole.xResearch.Director + MaritalStatus.xSingle + 
                 StockOptionLevel.x1 + EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                 EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                 JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                 WorkLifeBalance.x4 + JobInvolvement.x3 , family = "binomial", 
               data = train)


summary(model_10) 
sort(vif(model_10))

####Removing Age variable with VIF 1.847 and p-value 0.071. Since p-value is highest for the variable,
# we are removing it
model_11<- glm(formula = Attrition ~ NumCompaniesWorked + 
                 TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager +  
                 Average_Working_Hours_Q3 + BusinessTravel.xTravel_Frequently + 
                 BusinessTravel.xTravel_Rarely + Department.xResearch...Development + 
                 Department.xSales + JobLevel.x5 + JobRole.xManager + JobRole.xManufacturing.Director + 
                 JobRole.xResearch.Director + MaritalStatus.xSingle + 
                 StockOptionLevel.x1 + EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                 EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                 JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                 WorkLifeBalance.x4 + JobInvolvement.x3 , family = "binomial", 
               data = train)


summary(model_11) 
sort(vif(model_11))
 
####Removing StockOptionLevel.x1 variable with VIF 1.014688 and p-value 0.023031. Since p-value is highest for the variable,
# we are removing it
model_12<- glm(formula = Attrition ~ NumCompaniesWorked + 
                 TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager +  
                 Average_Working_Hours_Q3 + BusinessTravel.xTravel_Frequently + 
                 BusinessTravel.xTravel_Rarely + Department.xResearch...Development + 
                 Department.xSales + JobLevel.x5 + JobRole.xManager + JobRole.xManufacturing.Director + 
                 JobRole.xResearch.Director + MaritalStatus.xSingle + 
                 EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                 EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                 JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                 WorkLifeBalance.x4 + JobInvolvement.x3 , family = "binomial", 
               data = train)

summary(model_12) 
sort(vif(model_12))

####Removing JobRole.xManufacturing.Director variable with VIF 1.046862 and p-value  0.021058 . Since p-value is highest for the variable,
# we are removing it
model_13<- glm(formula = Attrition ~ NumCompaniesWorked + 
                 TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager +  
                 Average_Working_Hours_Q3 + BusinessTravel.xTravel_Frequently + 
                 BusinessTravel.xTravel_Rarely + Department.xResearch...Development + 
                 Department.xSales + JobLevel.x5 + JobRole.xManager + 
                 JobRole.xResearch.Director + MaritalStatus.xSingle + 
                 EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                 EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                 JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                 WorkLifeBalance.x4 + JobInvolvement.x3 , family = "binomial", 
               data = train)

summary(model_13) 
sort(vif(model_13))

####Removing JobRole.xManager variable with VIF 1.030696 and p-value  0.033476 . Since p-value is highest for the variable,
# we are removing it
model_14<- glm(formula = Attrition ~ NumCompaniesWorked + 
                 TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager +  
                 Average_Working_Hours_Q3 + BusinessTravel.xTravel_Frequently + 
                 BusinessTravel.xTravel_Rarely + Department.xResearch...Development + 
                 Department.xSales + JobLevel.x5 +  
                 JobRole.xResearch.Director + MaritalStatus.xSingle + 
                 EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                 EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                 JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                 WorkLifeBalance.x4 + JobInvolvement.x3 , family = "binomial", 
               data = train)


summary(model_14) 
sort(vif(model_14))  

####Removing JobLevel.x5 variable with VIF 1.037672 and p-value  0.009622 . Since p-value is highest for the variable,
# we are removing it
model_15<- glm(formula = Attrition ~ NumCompaniesWorked + 
                 TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager +  
                 Average_Working_Hours_Q3 + BusinessTravel.xTravel_Frequently + 
                 BusinessTravel.xTravel_Rarely + Department.xResearch...Development + 
                 Department.xSales +  
                 JobRole.xResearch.Director + MaritalStatus.xSingle + 
                 EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                 EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                 JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                 WorkLifeBalance.x4 + JobInvolvement.x3 , family = "binomial", 
               data = train)


summary(model_15) 
sort(vif(model_15))  

####Removing JobRole.xResearch.Director variable with VIF 1.021508 and p-value  0.009041 . Since p-value is highest for the variable,
# we are removing it
model_16<- glm(formula = Attrition ~ NumCompaniesWorked + 
                 TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager +  
                 Average_Working_Hours_Q3 + BusinessTravel.xTravel_Frequently + 
                 BusinessTravel.xTravel_Rarely + Department.xResearch...Development + 
                 Department.xSales +  
                 MaritalStatus.xSingle + 
                 EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                 EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                 JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                 WorkLifeBalance.x4 + JobInvolvement.x3 , family = "binomial", 
               data = train)

summary(model_16) 
sort(vif(model_16))  

####Removing JobInvolvement.x3 variable with VIF 1.041029 and p-value  0.004799 . Since p-value is highest for the variable,
# we are removing it
model_17<- glm(formula = Attrition ~ NumCompaniesWorked + 
                 TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager +  
                 Average_Working_Hours_Q3 + BusinessTravel.xTravel_Frequently + 
                 BusinessTravel.xTravel_Rarely + Department.xResearch...Development + 
                 Department.xSales +  
                 MaritalStatus.xSingle + 
                 EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                 EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                 JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                 WorkLifeBalance.x4 , family = "binomial", 
               data = train)


summary(model_17) 
sort(vif(model_17))  

####Removing WorkLifeBalance.x4 variable with VIF 2.307905 and p-value  0.004664 . Since p-value is highest for the variable,
# we are removing it
model_18<- glm(formula = Attrition ~ NumCompaniesWorked + 
                 TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager +  
                 Average_Working_Hours_Q3 + BusinessTravel.xTravel_Frequently + 
                 BusinessTravel.xTravel_Rarely + Department.xResearch...Development + 
                 Department.xSales +  
                 MaritalStatus.xSingle + 
                 EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                 EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                 JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3
               , family = "binomial", 
               data = train)


summary(model_18) 
sort(vif(model_18))  


####Removing WorkLifeBalance.x2 variable with VIF 1.753588 and p-value  0.163736 . Since p-value is highest for the variable,
# we are removing it
model_19<- glm(formula = Attrition ~ NumCompaniesWorked + 
                 TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager +  
                 Average_Working_Hours_Q3 + BusinessTravel.xTravel_Frequently + 
                 BusinessTravel.xTravel_Rarely + Department.xResearch...Development + 
                 Department.xSales +  
                 MaritalStatus.xSingle + 
                 EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                 EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                 JobSatisfaction.x4 + WorkLifeBalance.x3
               , family = "binomial", 
               data = train)


summary(model_19) 
sort(vif(model_19))  


####Removing WorkLifeBalance.x3 variable with VIF 1.021678 and p-value  0.003310 . Since p-value is highest for the variable,
# we are removing it
model_20<- glm(formula = Attrition ~ NumCompaniesWorked + 
                 TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager +  
                 Average_Working_Hours_Q3 + BusinessTravel.xTravel_Frequently + 
                 BusinessTravel.xTravel_Rarely + Department.xResearch...Development + 
                 Department.xSales +  
                 MaritalStatus.xSingle + 
                 EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                 EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                 JobSatisfaction.x4  , family = "binomial", 
               data = train)


summary(model_20) 
sort(vif(model_20))  

####Removing BusinessTravel.xTravel_Rarely variable with VIF 3.676749 and p-value  0.004688 . Since p-value is highest for the variable,
# we are removing it
model_21<- glm(formula = Attrition ~ NumCompaniesWorked + 
                 TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager +  
                 Average_Working_Hours_Q3 + BusinessTravel.xTravel_Frequently + 
                 Department.xResearch...Development + 
                 Department.xSales +  
                 MaritalStatus.xSingle + 
                 EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                 EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                 JobSatisfaction.x4  , family = "binomial", 
               data = train)


summary(model_21) 
sort(vif(model_21))  

####Removing Department.xSales variable with VIF 3.983229 and p-value  0.000158 . Since p-value is highest for the variable,
# we are removing it
model_22<- glm(formula = Attrition ~ NumCompaniesWorked + 
                 TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager +  
                 Average_Working_Hours_Q3 + BusinessTravel.xTravel_Frequently + 
                 Department.xResearch...Development + 
                 MaritalStatus.xSingle + EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                 EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                 JobSatisfaction.x4  , family = "binomial", 
               data = train)


summary(model_22) 
sort(vif(model_22))  


####Removing Department.xResearch...Development variable with VIF 1.019174 and p-value  0.288098 . Since p-value is highest for the variable,
# we are removing it
model_23<- glm(formula = Attrition ~ NumCompaniesWorked + 
                 TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager +  
                 Average_Working_Hours_Q3 + BusinessTravel.xTravel_Frequently + 
                 MaritalStatus.xSingle + EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                 EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                 JobSatisfaction.x4  , family = "binomial", 
               data = train)


summary(model_23) 
sort(vif(model_23))  

####Removing JobSatisfaction.x2 variable with VIF 1.430538 and p-value  0.000398 . Since p-value is highest for the variable,
# we are removing it
model_24<- glm(formula = Attrition ~ NumCompaniesWorked + 
                 TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager +  
                 Average_Working_Hours_Q3 + BusinessTravel.xTravel_Frequently + 
                 MaritalStatus.xSingle + EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                 EnvironmentSatisfaction.x4 + JobSatisfaction.x3 + 
                 JobSatisfaction.x4  , family = "binomial", 
               data = train)


summary(model_24) 
sort(vif(model_24))  

####Removing JobSatisfaction.x3 variable with VIF 1.168478 and p-value  0.00385 . Since p-value is highest for the variable,
# we are removing it
model_25<- glm(formula = Attrition ~ NumCompaniesWorked + 
                 TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager +  
                 Average_Working_Hours_Q3 + BusinessTravel.xTravel_Frequently + 
                 MaritalStatus.xSingle + EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                 EnvironmentSatisfaction.x4 + JobSatisfaction.x4  , family = "binomial", 
               data = train)


summary(model_25) 
sort(vif(model_25))  

### Model Evaluation----

### Test Data ####
#predicted probabilities of Attrition for test data
test_pred = predict(model_25, type = "response", 
                    newdata = test[,-1])

summary(test_pred)
test$prob <- test_pred
View(test)

#Using Cutoff as 50%
test_pred_Attrition <- factor(ifelse(test_pred >= 0.50, "Yes", "No"))
test_actual_Attrition <- factor(ifelse(test$Attrition==1,"Yes","No"))
table(test_actual_Attrition,test_pred_Attrition)
test_conf <- confusionMatrix(test_pred_Attrition, test_actual_Attrition, positive = "Yes")
test_conf

#Using Cutoff as 40%
test_pred_Attrition <- factor(ifelse(test_pred >= 0.40, "Yes", "No"))
test_actual_Attrition <- factor(ifelse(test$Attrition==1,"Yes","No"))
table(test_actual_Attrition,test_pred_Attrition)
test_conf <- confusionMatrix(test_pred_Attrition, test_actual_Attrition, positive = "Yes")
test_conf

#Using Cutoff as 33%
test_pred_Attrition <- factor(ifelse(test_pred >= 0.33, "Yes", "No"))
test_actual_Attrition <- factor(ifelse(test$Attrition==1,"Yes","No"))
table(test_actual_Attrition,test_pred_Attrition)
test_conf <- confusionMatrix(test_pred_Attrition, test_actual_Attrition, positive = "Yes")
test_conf
#######################################################################

#Calculating CutOff Values
perform_fn <- function(cutoff) 
{
  predicted_Attrition <- factor(ifelse(test_pred >= cutoff, "Yes", "No"))
  conf <- confusionMatrix(predicted_Attrition, test_actual_Attrition, positive = "Yes")
  acc <- conf$overall[1]
  sens <- conf$byClass[1]
  spec <- conf$byClass[2]
  out <- t(as.matrix(c(sens, spec, acc))) 
  colnames(out) <- c("sensitivity", "specificity", "accuracy")
  return(out)
}

# Summary of test probability
summary(test_pred)
s = seq(.01,.80,length=100)
OUT = matrix(0,100,3)

for(i in 1:100)
{
  OUT[i,] = perform_fn(s[i])
} 

#Plotting Senstivity,Specificity and Accuracy
plot(s, OUT[,1],xlab="Cutoff",ylab="Value",cex.lab=1.5,cex.axis=1.5,ylim=c(0,1),type="l",lwd=2,axes=FALSE,col=2)
axis(1,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
axis(2,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
lines(s,OUT[,2],col="darkgreen",lwd=2)
lines(s,OUT[,3],col=4,lwd=2)
box()
legend(0,.50,col=c(2,"darkgreen",4,"darkred"),lwd=c(2,2,2,2),c("Sensitivity","Specificity","Accuracy"))

#Cutoff value from the above function
cutoff <- s[which(abs(OUT[,1]-OUT[,2])<0.03)]
cutoff

#Taking CutOff value as .1616 to optimize Accuracy,Specificity and senstivity
test_cutoff_Attrition <- factor(ifelse(test_pred >=0.1616, "Yes", "No"))
conf_final <- confusionMatrix(test_cutoff_Attrition, test_actual_Attrition, positive = "Yes")

#To view the Accuracy, Specificity and Senstivity
acc <- conf_final$overall[1]
sens <- conf_final$byClass[1]
spec <- conf_final$byClass[2]
acc
sens
spec

View(test)

##################################################################################################
### KS -statistic - Test Data ######----

test_cutoff_Attrition <- ifelse(test_cutoff_Attrition=="Yes",1,0)
test_actual_Attrition <- ifelse(test_actual_Attrition=="Yes",1,0)

#on testing  data
pred_object_test<- prediction(test_cutoff_Attrition, test_actual_Attrition)

performance_measures_test<- performance(pred_object_test, "tpr", "fpr")

ks_table_test <- attr(performance_measures_test, "y.values")[[1]] - 
  (attr(performance_measures_test, "x.values")[[1]])

max(ks_table_test)


####################################################################
# Lift & Gain Chart ----

# plotting the lift chart
lift <- function(labels , predicted_prob,groups=10) {
  
  if(is.factor(labels)) labels  <- as.integer(as.character(labels ))
  if(is.factor(predicted_prob)) predicted_prob <- as.integer(as.character(predicted_prob))
  helper = data.frame(cbind(labels , predicted_prob))
  helper[,"bucket"] = ntile(-helper[,"predicted_prob"], groups)
  gaintable = helper %>% group_by(bucket)  %>%
    summarise_at(vars(labels ), funs(total = n(),
                                     totalresp=sum(., na.rm = TRUE))) %>%
    
    mutate(Cumresp = cumsum(totalresp),
           Gain=Cumresp/sum(totalresp)*100,
           Cumlift=Gain/(bucket*(100/groups))) 
  return(gaintable)
}

Attrition_decile = lift(test_actual_Attrition, test_pred, groups = 10)

#########################################################################################################
# Positive Impact on attrition -
# Number of Companies Worked - More frequently a person changes company, has a tendency to switch company
# Years Since Last Promotion  - If a person is not promoted from a long time, he/she would tend to leave the company
# Average Working Hours for Quarter 3 
# Business Travel.(Travel Frequently) - If a person is travelling quite frequently he/she would leave the company
# Marital Status.(Single) - Single person are more likely to change the company. 
# 
# 
# Negative Impact on attrition:-
#   Total Working Years  - More experience a person gains, less likely they would leave the company. 
# Training Times Last Year -More number of training received by an employee, less likely he/she would leave
# Years With Current Manager   - More the number of years with the current manager, person less likely to leave 
# Environment Satisfaction(Medium) - Medium environment satisfaction, employee would retain.
# Environment Satisfaction.(High) - Better environment satisfaction, employee would retain.
# Environment Satisfaction.(Very High) - Very High environment satisfaction, employee would retain.
# Job Satisfaction (Very High) - Very High Job satisfaction, then person will not leave the company. 




######### Group Case Study Submission ##########
#----------------------------------------------#
## Retail-Giant Sales Forecasting case Study ###
#----------------------------------------------#

###### Business Understanding #######
#"Global Mart" is an online store super giant having worldwide operations. 
#It takes orders and delivers across the globe and deals with all the major product categories - consumer, corporate & home office in 7 differnt market segments.
#We need to forecast the sales and the demand for the next 6 months, that would help you manage the revenue and inventory accordingly.

###### Data Understanding ######
#The data currently has the transaction level data, where each row represents a particular order made on the online store. There are 24 attributes related to each such transaction. 
#The "Market" attribute has 7-factor levels representing the geographical market sector that the customer belongs to. 
#The "Segment" attribute tells which of the 3 segments that customer belongs to.

###### Data Preparation ######
#######Loading the Libraries#########
library(dplyr)
library(tidyr)
library(stringr)
library(ggplot2)
library(forecast)
library(tseries)
require(graphics)

#Loading the Data Frame
Global_Superstore <- read.csv("Global Superstore.csv",stringsAsFactors = F)

sum(is.na(Global_Superstore)) #Checking for NA values. total NA values are 41296
sum(is.na(Global_Superstore$Postal.Code)) # all the NA values are present in POstal Code column. Total NA values in postal code = 41296 

Na <- Global_Superstore[which(is.na(Global_Superstore$Postal.Code)),] # separating out na value subset for more data understanding
NotNA <- Global_Superstore[which(!is.na(Global_Superstore$Postal.Code)),] # separating out Not na value subset for more data understanding

Global_Superstore$Order.Date <- gsub('/','-',Global_Superstore$Order.Date) # Replacing "/" with "-" in Order Date column.
Global_Superstore$Ship.Date <- gsub('/','-',Global_Superstore$Ship.Date) # Replacing "/" with "-" in ship Date column.

#Converting dates into a standard format
Global_Superstore$Order.Date <- as.Date(Global_Superstore$Order.Date,format = "%d-%m-%Y")
Global_Superstore$Ship.Date <- as.Date(Global_Superstore$Ship.Date,format = "%d-%m-%Y")

#To extract the month and year from order Date
Global_Superstore$Order_Month <- format(Global_Superstore$Order.Date,"%m")
Global_Superstore$Order_Year <- format(Global_Superstore$Order.Date,"%Y")

#Segmenting the dataset based on market and segment
Global_store_Segment <-  group_by(Global_Superstore,Market,Segment)
Global_store_Segment <- summarise(Global_store_Segment,mean_profit = mean(Profit),sd_profit=sd(Profit),cov=sd_profit/mean_profit,sum_profit=sum(Profit), Quantity=sum(Quantity),Sales=sum(Sales))

# Grouping by Market, Segment, Order_Year & then Order_Month
Grouping_Global_store <-  group_by(Global_Superstore,Market,Segment,Order_Year,Order_Month)
Summary_Global_Store <- summarise(Grouping_Global_store,profit = sum(Profit),Quantity=sum(Quantity),Sales=sum(Sales))

#Plotting Total profit, Quantity and sales with market for different segments.
plot1<-ggplot(Global_store_Segment,aes(x=Global_store_Segment$Market,y=Global_store_Segment$sum_profit,fill=Global_store_Segment$Segment))
plot1+geom_bar(stat="identity",position="dodge")+xlab("Market")+ylab("Profit")+ggtitle("Total Profit")


plot2<-ggplot(Global_store_Segment,aes(x=Global_store_Segment$Market,y=Global_store_Segment$Quantity,fill=Global_store_Segment$Segment))
plot2+geom_bar(stat="identity",position="dodge")+xlab("Market")+ylab("QUantity")+ggtitle("Total Quantity")


# plot3<-ggplot(Global_store_Segment,aes(x=Global_store_Segment$Market,y=Global_store_Segment$Sales,fill=Global_store_Segment$Segment))
# plot3+geom_bar(stat="identity",position="dodge")+xlab("Market")+ylab("Sales")+ggtitle("Total Sales")
# 

plot4<-ggplot(Global_store_Segment,aes(x=Global_store_Segment$Market,y=Global_store_Segment$cov,fill=Global_store_Segment$Segment))
plot4+geom_bar(stat="identity",position="dodge")+xlab("Market")+ylab("cov")+ggtitle("Coefficient of variance")


# As per the initial anayses the 2 Most profitable segments are 
# 1. APAC Consumer 
# 2. EU Consumer

# As we are considering APAC and EU region for further analyses we can drop "Postal Code" column as all the values are NA for these 2 regions
Global_Superstore$Postal.Code <- NULL
str(Global_Superstore)

##############################################################################################
                                        #APAC Consumer#
##############################################################################################

#Creating subset of APAC Consumer
APAC_Consumer<-subset(Summary_Global_Store,(Summary_Global_Store$Market=="APAC")
                            &(Summary_Global_Store$Segment=="Consumer"))

# Ordering the subset based on the Order year
APAC_Consumer<-APAC_Consumer[order(APAC_Consumer$Order_Year),]

APAC_Consumer$MonthNo <- c(1:nrow(APAC_Consumer)) # To list the months as Numbers

###### Data Modelling APAC Consumer #########

#Preparing Data for time series Profit for APAC Consumer
APAC_Consumer_timeser <- data.frame(APAC_Consumer[,c("MonthNo","profit")])

total_timeser <- ts(APAC_Consumer_timeser$profit)
APAC_Consumer_InData <- APAC_Consumer_timeser[1:42,]
timeser <- ts(APAC_Consumer_InData$profit)


# Decomposing Time Series, into Trend Sesonality & Randomnes
APAC_Consumer_Profit_decomposition <-ts(timeser,frequency=12)
APAC_Consumer_Profit_decompose <- decompose(APAC_Consumer_Profit_decomposition)
plot(APAC_Consumer_Profit_decompose)

# Plotting Time series
plot(timeser)

#Smoothing the series - Moving Average Smoothing
w <-1
smoothedseries <- stats::filter(timeser, 
                         filter=rep(1/(2*w+1),(2*w+1)), 
                         method='convolution', sides=2)


#Smoothing left end of the time series
diff <- smoothedseries[w+2] - smoothedseries[w+1]
for (i in seq(w,1,-1)) {
  smoothedseries[i] <- smoothedseries[i+1] - diff
}

#Smoothing right end of the time series
n <- length(timeser)
diff <- smoothedseries[n-w] - smoothedseries[n-w-1]
for (i in seq(n-w+1, n)) {
  smoothedseries[i] <- smoothedseries[i-1] + diff
}

#Plotting the smoothed time series
timevals_in <- APAC_Consumer_InData$MonthNo
lines(smoothedseries, col="blue", lwd=2)

smootheddf <- as.data.frame(cbind(timevals_in, as.vector(smoothedseries)))
colnames(smootheddf) <- c('MonthNo', 'profit')

#Now,fittinga multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function

lmfit <- lm(profit ~ sin(0.5*MonthNo) * poly(MonthNo,3) + cos(0.5*MonthNo) * poly(MonthNo,3)
            + MonthNo, data=smootheddf)
global_pred <- predict(lmfit, Month=timevals_in)
summary(global_pred)
lines(timevals_in, global_pred, col='red', lwd=2)

# Predicting Local Part 
local_pred <- timeser-global_pred
plot(local_pred, col='red', type = "l")
acf(local_pred)
acf(local_pred, type="partial")
armafit <- auto.arima(local_pred)
#ARIMA(5,0,0) with zero mean 
tsdiag(armafit)
armafit

#checking if the residual series is white noise
resi <- local_pred-fitted(armafit)

#Augmented Dickey-Fuller Test
adf.test(resi,alternative = "stationary")
#Dickey-Fuller = -5.8694, Lag order = 3, p-value = 0.01 
#alternative hypothesis: stationary

#KPSS test
kpss.test(resi)
#KPSS Level = 0.020826, Truncation lag parameter = 1, p-value = 0.1

#evaluating  the model using MAPE
#making a prediction for the last 6 months
APAC_Consumer_timeser
APAC_Consumer_outData <- APAC_Consumer_timeser[43:48,]
timevals_out <- APAC_Consumer_outData$MonthNo
timevals_out
global_pred_out <- predict(lmfit,data.frame(MonthNo=timevals_out))

#Forecasting Global prediction
fcast <- global_pred_out

#comparing our prediction with the actual values, using MAPE
MAPE_class_dec <- accuracy(fcast,APAC_Consumer_outData[,2])[5]
MAPE_class_dec
#49.33045 is the value

#plotting the predictions along with original values
#get a visual feel of the fit
class_dec_pred <- c(ts(global_pred),ts(global_pred_out))
plot(total_timeser, col = "black")
lines(class_dec_pred, col = "red")

# Using ARIMA fit
autoarima <- auto.arima(timeser)
autoarima
tsdiag(autoarima)
plot(autoarima$x, col="black")
lines(fitted(autoarima), col="red")

#checking if the residual series is white noise
resi_auto_arima <- timeser - fitted(autoarima)

##Augmented Dickey-Fuller Test
adf.test(resi_auto_arima,alternative = "stationary")
#Dickey-Fuller = -3.1321, Lag order = 3, p-value = 0.1274
#alternative hypothesis: stationary

#KPSS test
kpss.test(resi_auto_arima)
#KPSS Level = 0.05328, Truncation lag parameter = 1, p-value = 0.1


#Evaluating the model using MAPE
fcast_auto_arima <- predict(autoarima, n.ahead = 6)

MAPE_auto_arima <- accuracy(fcast_auto_arima$pred,APAC_Consumer_outData[,2])[5]
MAPE_auto_arima
#41.29419

#Plotting the predictions along with original values, to
#get a visual feel of the fit

auto_arima_pred <- c(fitted(autoarima),ts(fcast_auto_arima$pred))
plot(total_timeser, col = "black")
lines(auto_arima_pred, col = "red")

forecast(autoarima,h=6)
#########################################

# APAC Consumer quantity  
#Preparing Time series for APAC Consumer Quantity

APAC_Consumer_timeser_quantity <- data.frame(APAC_Consumer[,c("MonthNo","Quantity")])
total_timeser_quantity <- ts(APAC_Consumer_timeser_quantity$Quantity)
APAC_Consumer_InData_quantity <- APAC_Consumer_timeser_quantity[1:42,]
timeser_quantity <- ts(APAC_Consumer_InData_quantity$Quantity)

# Decomposing Time Series, into Trend Sesonality & Randomnes
APAC_Consumer_Quantity_decomposition <-ts(timeser_quantity,frequency=12)
APAC_Consumer_Quantity_decompose <- decompose(APAC_Consumer_Quantity_decomposition)
plot(APAC_Consumer_Quantity_decompose)


#Plotting Time Series
plot(timeser_quantity)

#Smoothing the series - Moving Average Smoothing
w <-1
smoothedseries_quantity <- stats::filter(timeser_quantity, 
                                filter=rep(1/(2*w+1),(2*w+1)), 
                                method='convolution', sides=2)


#Smoothing left end of the time series
diff_quantity <- smoothedseries_quantity[w+2] - smoothedseries_quantity[w+1]
for (i in seq(w,1,-1)) {
  smoothedseries_quantity[i] <- smoothedseries_quantity[i+1] - diff_quantity
}

#Smoothing right end of the time series
n <- length(timeser_quantity)
diff_quantity <- smoothedseries_quantity[n-w] - smoothedseries_quantity[n-w-1]
for (i in seq(n-w+1, n)) {
  smoothedseries_quantity[i] <- smoothedseries_quantity[i-1] + diff_quantity
}

#Plot the smoothed time series
timevals_in_quantity <- APAC_Consumer_InData_quantity$MonthNo
lines(smoothedseries_quantity, col="blue", lwd=2)

smootheddf_quantity <- as.data.frame(cbind(timevals_in_quantity, as.vector(smoothedseries_quantity)))
colnames(smootheddf_quantity) <- c('MonthNo', 'Quantity')

#fitting a multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function

lmfit_quantity <- lm(Quantity ~ sin(0.5*MonthNo) * poly(MonthNo,3) + cos(0.5*MonthNo) * poly(MonthNo,3)
            + MonthNo, data=smootheddf_quantity)
global_pred_quantity <- predict(lmfit_quantity, Month=timevals_in_quantity)
summary(global_pred_quantity)
lines(timevals_in_quantity, global_pred_quantity, col='red', lwd=2)

# Local Preditions
local_pred_quantity <- timeser_quantity-global_pred_quantity
plot(local_pred_quantity, col='red', type = "l")
acf(local_pred_quantity)
acf(local_pred_quantity, type="partial")
armafit_quantity <- auto.arima(local_pred_quantity)

tsdiag(armafit_quantity)
armafit_quantity
#ARIMA(0,0,0) with zero mean 

#checking if the residual series is white noise
resi_quantity <- local_pred_quantity-fitted(armafit_quantity)

##Augmented Dickey-Fuller Test
adf.test(resi_quantity,alternative = "stationary")

#Dickey-Fuller = -7.4893, Lag order = 3, p-value = 0.01,alternative hypothesis: stationary

#KPSS Test

kpss.test(resi_quantity)
#KPSS Level = 0.01898, Truncation lag parameter = 1, p-value = 0.1

#Evaluating the model using MAPE
#Making a prediction for the last 6 months
APAC_Consumer_timeser_quantity
APAC_Consumer_outData_quantity <- APAC_Consumer_timeser_quantity[43:48,]
timevals_out_quantity <- APAC_Consumer_outData_quantity$MonthNo
timevals_out_quantity
global_pred_out_quantity <- predict(lmfit_quantity,data.frame(MonthNo=timevals_out_quantity))

#Forecasting Global trends
fcast_quantity <- global_pred_out_quantity

#Comparing our prediction with the actual values, using MAPE
MAPE_class_quantity <- accuracy(fcast_quantity,APAC_Consumer_outData_quantity[,2])[5]
MAPE_class_quantity
#62.10289

#Plotting the predictions along with original values, to get a visual feel of the fit
class_quantity_pred <- c(ts(global_pred_quantity),ts(global_pred_out_quantity))
plot(total_timeser_quantity, col = "black")
lines(class_quantity_pred, col = "red")
forecast(class_quantity_pred,h=6)


#Using ARIMA fit
autoarima_quantity <- auto.arima(timeser_quantity)
autoarima_quantity
tsdiag(autoarima_quantity)
plot(autoarima_quantity$x, col="black")
lines(fitted(autoarima_quantity), col="red")

#checking if the residual series is white noise
resi_auto_arima_quantity <- timeser_quantity - fitted(autoarima_quantity)

##Augmented Dickey-Fuller Test
adf.test(resi_auto_arima_quantity,alternative = "stationary")
#Dickey-Fuller = -4.3326, Lag order = 3, p-value = 0.01, alternative hypothesis: stationary

#KPSS Test
kpss.test(resi_auto_arima_quantity)
#KPSS Level = 0.031535, Truncation lag parameter = 1, p-value = 0.1


#Evaluating the model using MAPE
fcast_auto_arima_quantity <- predict(autoarima_quantity, n.ahead = 6)

MAPE_auto_arima_quantity <- accuracy(fcast_auto_arima_quantity$pred,APAC_Consumer_outData_quantity[,2])[5]
MAPE_auto_arima_quantity
#26.24458

#Plotting the predictions along with original values, to get a visual feel of the fit

auto_arima_pred_quantity <- c(fitted(autoarima_quantity),ts(fcast_auto_arima_quantity$pred))
plot(total_timeser_quantity, col = "black")
lines(auto_arima_pred_quantity, col = "red")

forecast(autoarima_quantity,h=6)

############################################
# APAC Consumer Sales  

#Preparing Time series for APAC Consumer Sales
APAC_Consumer_timeser_sales <- data.frame(APAC_Consumer[,c("MonthNo","Sales")])
total_timeser_sales <- ts(APAC_Consumer_timeser_sales$Sales)
APAC_Consumer_InData_sales <- APAC_Consumer_timeser_sales[1:42,]
timeser_sales <- ts(APAC_Consumer_InData_sales$Sales)

# Decomposing Time Series, into Trend Sesonality & Randomnes
APAC_Consumer_Sales_decomposition <-ts(timeser_sales,frequency=12)
APAC_Consumer_Sales_decompose <- decompose(APAC_Consumer_Sales_decomposition)
plot(APAC_Consumer_Sales_decompose)

#Plotting Time series for Sales
plot(timeser_sales)



#Smoothing the series - Moving Average Smoothing
w <-1
smoothedseries_sales <- stats::filter(timeser_sales, 
                                      filter=rep(1/(2*w+1),(2*w+1)), 
                                      method='convolution', sides=2)

#Smoothing left end of the time series
diff_sales <- smoothedseries_sales[w+2] - smoothedseries_sales[w+1]
for (i in seq(w,1,-1)) {
  smoothedseries_sales[i] <- smoothedseries_sales[i+1] - diff_sales
}

#Smoothing right end of the time series
n <- length(timeser_sales)
diff_sales <- smoothedseries_sales[n-w] - smoothedseries_sales[n-w-1]
for (i in seq(n-w+1, n)) {
  smoothedseries_sales[i] <- smoothedseries_sales[i-1] + diff_sales
}

#Plot the smoothed time series
timevals_in_sales <- APAC_Consumer_InData_sales$MonthNo
lines(smoothedseries_sales, col="blue", lwd=2)

smootheddf_sales <- as.data.frame(cbind(timevals_in_sales, as.vector(smoothedseries_sales)))
colnames(smootheddf_sales) <- c('MonthNo', 'Sales')

#Fitting a multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function

lmfit_sales <- lm(Sales ~ sin(0.5*MonthNo) * poly(MonthNo,3) + cos(0.5*MonthNo) * poly(MonthNo,3)
                  + MonthNo, data=smootheddf_sales)
global_pred_sales <- predict(lmfit_sales, Month=timevals_in_sales)
summary(global_pred_sales)
lines(timevals_in_sales, global_pred_sales, col='red', lwd=2)

# Local Predictions
local_pred_sales <- timeser_sales-global_pred_sales
plot(local_pred_sales, col='red', type = "l")
acf(local_pred_sales)
acf(local_pred_sales, type="partial")
armafit_sales <- auto.arima(local_pred_sales)

tsdiag(armafit_sales)
armafit_sales
#ARIMA (0,0,0) with Zero mean

#Checking if the residual series is white noise
resi_sales <- local_pred_sales-fitted(armafit_sales)

##Augmented Dickey-Fuller Test
adf.test(resi_sales,alternative = "stationary")
#Dickey-Fuller = -6.8673, Lag order = 3, p-value = 0.01,alternative hypothesis: stationary


#KPSS Test
kpss.test(resi_sales)

#KPSS Level = 0.021731, Truncation lag parameter = 1, p-value = 0.1


#Evaluating the model using MAPE
#Making a prediction for the last 6 months
APAC_Consumer_timeser_sales
APAC_Consumer_outData_sales <- APAC_Consumer_timeser_sales[43:48,]
timevals_out_sales <- APAC_Consumer_outData_sales$MonthNo
timevals_out_sales
global_pred_out_sales <- predict(lmfit_sales,data.frame(MonthNo=timevals_out_sales))

fcast_sales <- global_pred_out_sales

#Comparing our prediction with the actual values, using MAPE
MAPE_class_sales <- accuracy(fcast_sales,APAC_Consumer_outData_sales[,2])[5]
MAPE_class_sales
#31.07429

#Plotting the predictions along with original values, to
#get a visual feel of the fit
class_sales_pred <- c(ts(global_pred_sales),ts(global_pred_out_sales))
plot(total_timeser_sales, col = "black")
lines(class_sales_pred, col = "red")

#Using ARIMA fit
autoarima_sales <- auto.arima(timeser_sales)
autoarima_sales
#ARIMA(0,1,1)

tsdiag(autoarima_sales)
plot(autoarima_sales$x, col="black")
lines(fitted(autoarima_sales), col="red")

#Check if the residual series is white noise
resi_auto_arima_sales <- timeser_sales - fitted(autoarima_sales)

##Augmented Dickey-Fuller Test
adf.test(resi_auto_arima_sales,alternative = "stationary")
#Dickey-Fuller = -4.2563, Lag order = 3, p-value = 0.01,alternative hypothesis: stationary

#KPSS Test
kpss.test(resi_auto_arima_sales)
#KPSS Level = 0.042734, Truncation lag parameter = 1, p-value = 0.1

#Evaluating the model using MAPE
fcast_auto_arima_sales <- predict(autoarima_sales, n.ahead = 6)

MAPE_auto_arima_sales <- accuracy(fcast_auto_arima_sales$pred,APAC_Consumer_outData_sales[,2])[5]
MAPE_auto_arima_sales
#27.68952

#Ploting the predictions along with original values, to
#get a visual feel of the fit
auto_arima_pred_sales <- c(fitted(autoarima_sales),ts(fcast_auto_arima_sales$pred))
plot(total_timeser_sales, col = "black")
lines(auto_arima_pred_sales, col = "red")

forecast(autoarima_sales,h=6)

###########################################################################################
                                      #EU Consumers#
############################################################################################

### EU Consumer Profit

#Creating subset of EU Consumer
EU_Consumer<-subset(Summary_Global_Store,(Summary_Global_Store$Market=="EU")
                    &(Summary_Global_Store$Segment=="Consumer"))

# Ordering the EU Consumer Subset
EU_Consumer<-EU_Consumer[order(EU_Consumer$Order_Year),]
EU_Consumer$MonthNo <- c(1:nrow(EU_Consumer)) # To list the months as Numbers

#Preparing Data for time series Profit
EU_Consumer_timeser_profit <- data.frame(EU_Consumer[,c("MonthNo","profit")])

total_timeser_profit_EU <- ts(EU_Consumer_timeser_profit$profit)
EU_Consumer_InData_profit <- EU_Consumer_timeser_profit[1:42,]
timeser_profit_EU <- ts(EU_Consumer_InData_profit$profit)

# Decomposing Time Series, into Trend Sesonality & Randomnes
EU_Consumer_Profit_decomposition <-ts(timeser_profit_EU,frequency=12)
EU_Consumer_Profit_decompose <- decompose(EU_Consumer_Profit_decomposition)
plot(EU_Consumer_Profit_decompose)

#Plotting Time Series
plot(timeser_profit_EU)

#Smoothing the series - Moving Average Smoothing
w <- 1
smoothedseries_profit <- stats::filter(timeser_profit_EU, 
                                       filter=rep(1/(2*w+1),(2*w+1)), 
                                       method='convolution', sides=2)

#Smoothing left end of the time series
diff_profit <- smoothedseries_profit[w+2] - smoothedseries_profit[w+1]
for (i in seq(w,1,-1)) {
  smoothedseries_profit[i] <- smoothedseries_profit[i+1] - diff_profit
}

#Smoothing right end of the time series
n <- length(timeser_profit_EU)
diff_profit <- smoothedseries_profit[n-w] - smoothedseries_profit[n-w-1]
for (i in seq(n-w+1, n)) {
  smoothedseries_profit[i] <- smoothedseries_profit[i-1] + diff_profit
}

#Plotting the smoothed time series
timevals_in_profit_EU <- EU_Consumer_InData_profit$MonthNo
lines(smoothedseries_profit, col="blue", lwd=2)

smootheddf_profit <- as.data.frame(cbind(timevals_in_profit_EU, as.vector(smoothedseries_profit)))
colnames(smootheddf_profit) <- c('MonthNo', 'profit')

#Fitting a multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function
lmfit_profit <- lm(profit ~ sin(0.5*MonthNo) * poly(MonthNo,3) + cos(0.5*MonthNo) * poly(MonthNo,3)
                   + MonthNo, data=smootheddf_profit)
global_pred_profit <- predict(lmfit_profit, Month=timevals_in_profit_EU)
summary(global_pred_profit)
lines(timevals_in_profit_EU, global_pred_profit, col='red', lwd=2)

# Local Predictions
local_pred_profit_EU <- timeser_profit_EU - global_pred_profit
plot(local_pred_profit_EU, col='red', type = "l")
acf(local_pred_profit_EU)
acf(local_pred_profit_EU, type="partial")
armafit_profit_EU <- auto.arima(local_pred_profit_EU)

tsdiag(armafit_profit_EU)
armafit_profit_EU
#ARIMA(0,0,0) with Zero Mean

#Checking if the residual series is white noise
resi_profit_EU <- local_pred_profit_EU - fitted(armafit_profit_EU)

##Augmented Dickey-Fuller Test
adf.test(resi_profit_EU,alternative = "stationary")
#Dickey-Fuller = -6.5694, Lag order = 3, p-value = 0.01

#KPSS Test
kpss.test(resi_profit_EU)
# KPSS Level = 0.018786, Truncation lag parameter = 1, p-value = 0.1

#Evaluating the model using MAPE
#Making a prediction for the last 6 months
EU_Consumer_timeser_profit
EU_Consumer_outData_profit <- EU_Consumer_timeser_profit[43:48,]
timevals_out_profit <- EU_Consumer_outData_profit$MonthNo
timevals_out_profit
global_pred_out_profit_EU <- predict(lmfit_profit,data.frame(MonthNo=timevals_out_profit))

#Forecasting profit for EU Consumer
fcast_profit_EU <- global_pred_out_profit_EU

#comparing our prediction with the actual values, using MAPE
MAPE_class_profit_EU <- accuracy(fcast_profit_EU,EU_Consumer_outData_profit[,2])[5]
MAPE_class_profit_EU
#MAPE:- 241.0627

#Plot the Predictions along with original values, to get a visual feel of the fit

class_profit_pred_EU <- c(ts(global_pred_profit),ts(global_pred_out_profit_EU))
plot(total_timeser_profit_EU, col = "black")
lines(class_profit_pred_EU, col = "red")

#Using ARIMA fit
autoarima_profit_EU <- auto.arima(timeser_profit_EU)
autoarima_profit_EU
tsdiag(autoarima_profit_EU)
plot(autoarima_profit_EU$x, col="black")
lines(fitted(autoarima_profit_EU), col="red")

#Checking if the residual series is white noise
resi_auto_arima_profit_EU <- timeser_profit_EU - fitted(autoarima_profit_EU)

##Augmented Dickey-Fuller Test
adf.test(resi_auto_arima_profit_EU,alternative = "stationary")
#Dickey-Fuller = -4.0991, Lag order = 3, p-value = 0.01529, alternative hypothesis: stationary

#KPSS Test
kpss.test(resi_auto_arima_profit_EU)
#KPSS Level = 0.091257, Truncation lag parameter = 1, p-value = 0.1

#Evaluating the model using MAPE
fcast_auto_arima_profit_EU <- predict(autoarima_profit_EU, n.ahead = 6)

MAPE_auto_arima_profit_EU <- accuracy(fcast_auto_arima_profit_EU$pred,EU_Consumer_outData_profit[,2])[5]
MAPE_auto_arima_profit_EU
#38.97198

#Plotting the predictions along with original values, to get a visual feel of the fit

auto_arima_pred_profit_EU <- c(fitted(autoarima_profit_EU),ts(fcast_auto_arima_profit_EU$pred))
plot(total_timeser_profit_EU, col = "black")
lines(auto_arima_pred_profit_EU, col = "red")

forecast(autoarima_profit_EU,h=6)

#########################################
# EU Consumer quantity  

#Preparing Time series for EU Consumer Quantity
EU_Consumer_timeser_quantity <- data.frame(EU_Consumer[,c("MonthNo","Quantity")])

#class(EU_Consumer_timeser)
total_timeser_quantity_EU <- ts(EU_Consumer_timeser_quantity$Quantity)
EU_Consumer_InData_quantity <- EU_Consumer_timeser_quantity[1:42,]
timeser_quantity_EU <- ts(EU_Consumer_InData_quantity$Quantity)

#Plotting Time series for EU Consumer Quantity
plot(timeser_quantity_EU)

# Decomposing Time Series, into Trend Sesonality & Randomnes
EU_Consumer_Quantity_decomposition <-ts(timeser_quantity_EU,frequency=12)
EU_Consumer_Quantity_decompose <- decompose(EU_Consumer_Quantity_decomposition)
plot(EU_Consumer_Quantity_decompose)

#Smoothing the series - Moving Average Smoothing
w <- 1
smoothedseries_quantity_EU <- stats::filter(timeser_quantity_EU, 
                                         filter=rep(1/(2*w+1),(2*w+1)), 
                                         method='convolution', sides=2)

#Smoothing left end of the time series
diff_quantity_EU <- smoothedseries_quantity_EU[w+2] - smoothedseries_quantity_EU[w+1]
for (i in seq(w,1,-1)) {
  smoothedseries_quantity_EU[i] <- smoothedseries_quantity_EU[i+1] - diff_quantity_EU
}

#Smoothing right end of the time series
n <- length(timeser_quantity_EU)
diff_quantity_EU <- smoothedseries_quantity_EU[n-w] - smoothedseries_quantity_EU[n-w-1]
for (i in seq(n-w+1, n)) {
  smoothedseries_quantity_EU[i] <- smoothedseries_quantity_EU[i-1] + diff_quantity_EU
}

#Plot the smoothed time series
timevals_in_quantity_EU <- EU_Consumer_InData_quantity$MonthNo
lines(smoothedseries_quantity_EU, col="blue", lwd=2)

smootheddf_quantity_EU <- as.data.frame(cbind(timevals_in_quantity_EU, as.vector(smoothedseries_quantity_EU)))
colnames(smootheddf_quantity_EU) <- c('MonthNo', 'Quantity')

#Fitting a multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function
lmfit_quantity_EU <- lm(Quantity ~ sin(0.5*MonthNo) * poly(MonthNo,3) + cos(0.5*MonthNo) * poly(MonthNo,3)
                     + MonthNo, data=smootheddf_quantity_EU)
global_pred_quantity_EU <- predict(lmfit_quantity_EU, Month=timevals_in_quantity_EU)
summary(global_pred_quantity_EU)
lines(timevals_in_quantity_EU, global_pred_quantity_EU, col='red', lwd=2)

# Predicting Local Trends
local_pred_quantity_EU <- timeser_quantity_EU-global_pred_quantity_EU
plot(local_pred_quantity_EU, col='red', type = "l")
acf(local_pred_quantity_EU)
acf(local_pred_quantity_EU, type="partial")
armafit_quantity_EU <- auto.arima(local_pred_quantity_EU)

tsdiag(armafit_quantity_EU)
armafit_quantity_EU
#ARIMA(2,0,0) with Zero Mean

#Checking if the residual series is white noise
resi_quantity_EU <- local_pred_quantity_EU-fitted(armafit_quantity_EU)

##Augmented Dickey-Fuller Test
adf.test(resi_quantity_EU,alternative = "stationary")
#Dickey-Fuller = -6.6825, Lag order = 3, p-value = 0.01, alternative hypothesis: stationary

#KPSS Test
kpss.test(resi_quantity_EU)
#KPSS Level = 0.023531, Truncation lag parameter = 1, p-value = 0.1

#Evaluating the model using MAPE
#Making a prediction for the last 6 months

EU_Consumer_timeser_quantity
EU_Consumer_outData_quantity <- EU_Consumer_timeser_quantity[43:48,]
timevals_out_quantity_EU <- EU_Consumer_outData_quantity$MonthNo

global_pred_out_quantity_EU <- predict(lmfit_quantity_EU,data.frame(MonthNo=timevals_out_quantity_EU))

# Forecating Global Trends
fcast_quantity_EU <- global_pred_out_quantity_EU

#compare our prediction with the actual values, using MAPE
MAPE_class_quantity_EU <- accuracy(fcast_quantity_EU,EU_Consumer_outData_quantity[,2])[5]
MAPE_class_quantity_EU
#30.39741

#Plotting the predictions along with original values, to
#get a visual feel of the fit
class_quantity_pred_EU <- c(ts(global_pred_quantity_EU),ts(global_pred_out_quantity_EU))
plot(total_timeser_quantity_EU, col = "black")
lines(class_quantity_pred_EU, col = "red")

#Using ARIMA fit
autoarima_quantity_EU <- auto.arima(timeser_quantity_EU)
autoarima_quantity_EU
tsdiag(autoarima_quantity_EU)
plot(autoarima_quantity_EU$x, col="black")
lines(fitted(autoarima_quantity_EU), col="red")

#Checking if the residual series is white noise
resi_auto_arima_quantity_EU <- timeser_quantity_EU - fitted(autoarima_quantity_EU)

##Augmented Dickey-Fuller Test
adf.test(resi_auto_arima_quantity_EU,alternative = "stationary")
#Dickey-Fuller = -3.5969, Lag order = 3, p-value = 0.04521, alternative hypothesis: stationary

#KPSS Test
kpss.test(resi_auto_arima_quantity_EU)
 # KPSS Level = 0.047939, Truncation lag parameter = 1, p-value = 0.1

#Evaluating the model using MAPE
fcast_auto_arima_quantity_EU <- predict(autoarima_quantity_EU, n.ahead = 6)

MAPE_auto_arima_quantity_EU <- accuracy(fcast_auto_arima_quantity_EU$pred,EU_Consumer_outData_quantity[,2])[5]
MAPE_auto_arima_quantity_EU
#MAPE:- 30.13319

#Plotting the predictions along with original values, to get a visual feel of the fit

auto_arima_pred_quantity_EU <- c(fitted(autoarima_quantity_EU),ts(fcast_auto_arima_quantity_EU$pred))
plot(total_timeser_quantity_EU, col = "black")
lines(auto_arima_pred_quantity_EU, col = "red")

forecast(autoarima_quantity_EU,h=6)

############################################
# EU Consumer Sales  
#Preparing Time series for EU Consumer Sales
EU_Consumer_timeser_sales <- data.frame(EU_Consumer[,c("MonthNo","Sales")])
total_timeser_sales_EU <- ts(EU_Consumer_timeser_sales$Sales)
EU_Consumer_InData_sales <- EU_Consumer_timeser_sales[1:42,]
timeser_sales_EU <- ts(EU_Consumer_InData_sales$Sales)

#Plotting Time series sales EU 
plot(timeser_sales_EU)

# Decomposing Time Series, into Trend Sesonality & Randomnes
EU_Consumer_Sales_decomposition <-ts(timeser_sales_EU,frequency=12)
EU_Consumer_Sales_decompose <- decompose(EU_Consumer_Sales_decomposition)
plot(EU_Consumer_Sales_decompose)


#Smoothing the series - Moving Average Smoothing
w <-1
smoothedseries_sales_EU <- stats::filter(timeser_sales_EU, 
                                      filter=rep(1/(2*w+1),(2*w+1)), 
                                      method='convolution', sides=2)

#Smoothing left end of the time series
diff_sales_EU <- smoothedseries_sales_EU[w+2] - smoothedseries_sales_EU[w+1]
for (i in seq(w,1,-1)) {
  smoothedseries_sales_EU[i] <- smoothedseries_sales_EU[i+1] - diff_sales_EU
}

#Smoothing right end of the time series
n <- length(timeser_sales_EU)
diff_sales_EU <- smoothedseries_sales_EU[n-w] - smoothedseries_sales_EU[n-w-1]
for (i in seq(n-w+1, n)) {
  smoothedseries_sales_EU[i] <- smoothedseries_sales_EU[i-1] + diff_sales_EU
}

#Plot the smoothed time series
timevals_in_sales_EU <- EU_Consumer_InData_sales$MonthNo
lines(smoothedseries_sales_EU, col="blue", lwd=2)

smootheddf_sales_EU <- as.data.frame(cbind(timevals_in_sales_EU, as.vector(smoothedseries_sales_EU)))
colnames(smootheddf_sales_EU) <- c('MonthNo', 'Sales')

#Fitting a multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function
lmfit_sales_EU <- lm(Sales ~ sin(0.5*MonthNo) * poly(MonthNo,3) + cos(0.5*MonthNo) * poly(MonthNo,3)
                  + MonthNo, data=smootheddf_sales_EU)
global_pred_sales_EU <- predict(lmfit_sales_EU, Month=timevals_in_sales_EU)
summary(global_pred_sales_EU)
lines(timevals_in_sales_EU, global_pred_sales_EU, col='red', lwd=2)

# Predicting Local
local_pred_sales_EU <- timeser_sales_EU-global_pred_sales_EU
plot(local_pred_sales_EU, col='red', type = "l")
acf(local_pred_sales_EU)
acf(local_pred_sales_EU, type="partial")
armafit_sales_EU <- auto.arima(local_pred_sales_EU)

tsdiag(armafit_sales_EU)
armafit_sales_EU
#ARIMA(0,0,0) with Zero Mean

#Checking if the residual series is white noise
resi_sales_EU <- local_pred_sales_EU-fitted(armafit_sales_EU)

##Augmented Dickey-Fuller Test
adf.test(resi_sales_EU,alternative = "stationary")

#Dickey-Fuller = -7.3166, Lag order = 3, p-value = 0.01

#KPSS Test
kpss.test(resi_sales_EU)
#KPSS Level = 0.017855, Truncation lag parameter = 1, p-value = 0.1

#Evaluating the model using MAPE
#Making a prediction for the last 6 months
EU_Consumer_timeser_sales
EU_Consumer_outData_sales <- EU_Consumer_timeser_sales[43:48,]
timevals_out_sales_EU <- EU_Consumer_outData_sales$MonthNo
timevals_out_sales_EU
global_pred_out_sales_EU <- predict(lmfit_sales_EU,data.frame(MonthNo=timevals_out_sales_EU))

#Forecasting Global Values
fcast_sales_EU <- global_pred_out_sales_EU

#Comparing our prediction with the actual values, using MAPE
MAPE_class_sales_EU <- accuracy(fcast_sales_EU,EU_Consumer_outData_sales[,2])[5]
MAPE_class_sales_EU
#MAPE:- 92.95788

#Plotting the predictions along with original values, to get a visual feel of the fit

class_sales_pred_EU <- c(ts(global_pred_sales_EU),ts(global_pred_out_sales_EU))
plot(total_timeser_sales_EU, col = "black")
lines(class_sales_pred_EU, col = "red")

#Using ARIMA fit
autoarima_sales_EU <- auto.arima(timeser_sales_EU)
autoarima_sales_EU
tsdiag(autoarima_sales_EU)
plot(autoarima_sales_EU$x, col="black")
lines(fitted(autoarima_sales_EU), col="red")

#Checking if the residual series is white noise
resi_auto_arima_sales_EU <- timeser_sales_EU - fitted(autoarima_sales_EU)

##Augmented Dickey-Fuller Test
adf.test(resi_auto_arima_sales_EU,alternative = "stationary")
#Dickey-Fuller = -4.3522, Lag order = 3, p-value = 0.01

#KPSS
kpss.test(resi_auto_arima_sales_EU)
#KPSS Level = 0.05314, Truncation lag parameter = 1, p-value = 0.1


#Evaluating the model using MAPE
fcast_auto_arima_sales_EU <- predict(autoarima_sales_EU, n.ahead = 6)

MAPE_auto_arima_sales_EU <- accuracy(fcast_auto_arima_sales_EU$pred,EU_Consumer_outData_sales[,2])[5]
MAPE_auto_arima_sales_EU
#28.9226

#Plotting the predictions along with original values, to get a visual feel of the fit
auto_arima_pred_sales_EU <- c(fitted(autoarima_sales_EU),ts(fcast_auto_arima_sales_EU$pred))
plot(total_timeser_sales_EU, col = "black")
lines(auto_arima_pred_sales_EU, col = "red")

forecast(autoarima_sales_EU,h=6)
